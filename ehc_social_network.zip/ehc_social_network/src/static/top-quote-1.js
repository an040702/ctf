class quote1{
    constructor(){
    }

    all(){
        return {
            "Trần Dần":["https://hosonhanvat.net/wp-content/uploads/2020/08/tran-dan-la-ai-5.jpg","Tiếc ziên năm 2003, tự nhiên tui cầu ở nhà ở trên Phao san play. Tự nhiên tui thấy một hiện tượng lạ. Lúc đó tui mới thấy... ủa sao kì zậy? Tui nhìn 1 cái hình tượng... mà tui là đạo Phật. Tự nhiên tui thấy là... có hình có trái tym. Có trái tym màu hồng mà có cái ánh hào quang ra sao??? Mà tiếc ziên tui mắt thấy tai nghe chứ k phải tui nằm chiêm bao... Tui dụi mắt thêm 1 lần nữa... à tui thấy! Nhưng mà cái ông Chúa Jesus ông lại đứng ngoài ban công niệm kinh Koran bằng tiếng Ziệt???"],
            "Huỳnh Trần Ý Nhi":["https://static-images.vnncdn.net/files/publish/2023/7/23/img-4886-51.jpg","Trong khi bạn bè đồng trang lứa với em chỉ dành thời gian để ngủ, để chơi, để uống trà sữa thì em đã tham dự cuộc thi hoa hậu. Em nghĩ mình trưởng thành hơn các bạn, khi mà các bạn vừa đi học vừa đi làm thì em đã là một hoa hậu. Từ giờ em sẽ giữ mình hơn để xứng đáng với cương vị của một hoa hậu. Bạn trai em cũng cần phải có những thay đổi nhanh chóng mới theo kịp em."],
            "Trương Anh Ngọc": ['https://danviet.mediacdn.vn/296231569849192448/2021/6/29/anh-ngoc2-15968655217001799867904-16249426509631127006605.jpg','Bạn Chỉnh ơi, bạn đang comment 1 câu anh không thích chút nào nhé! Rất nhiều bạn cứ nhai đi nhai lại cái câu là "Tin chuẩn chưa anh?", muốn biết "Tin chuẩn chưa anh?" thì hãy so sánh, hãy đọc các nguồn tin khác, hãy đọc báo. Nếu đọc được một tin mà vẫn còn cảm thấy rằng là "À, chưa tin nổi" thì mình phải đi tìm kiếm các chỗ khác thay vì hỏi một câu cứ nhai đi nhai lại như một con bò là "Tin chuẩn chưa anh" rồi là vào cười haha xong rồi vào viết linh ta linh tinh ở trên đấy. Thì thay vì như thế các bạn hãy làm một việc này cho mình, hãy đi tìm xem, đọc trên các báo khác, hãy tìm đọc trên các fanpage khác, hãy biết tiếng Anh để hiểu các nguồn tin của nước ngoài thay vì cứ đi hỏi "Tin chuẩn chưa anh?", tất cả những ai vào hỏi: "Tin chuẩn chưa anh", mình đều một là xóa, hai là block hết. Mình không thích chuyện này, nếu không tin bất cứ một vấn đề gì, thậm chí nếu không tin mình, các bạn có thể bỏ follow mình, không theo dõi fanpage của mình nhưng đừng bao giờ hỏi một câu là "Tin chuẩn chưa anh?", không hay ho một chút nào cả, các bạn nhá! Một là block, hai là xóa, không có chuyện cứ nhai đi nhai lại cái một câu là "Tin chuẩn chưa anh?".'],
            "Nờ Ô Nô": ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGLNimomKVfdAc35Gmra2GK6cC95BwWXHCAw&usqp=CAU", "Hé lô bà già nghèo khổ giữa trời đông cô đơn!"]
        }
    }

}

let instance = new quote1()
exports.default = instance;
module.exports = exports['default'];