### Cách deploy challenge này trên local
- Build và run: tại thư mục này chạy lệnh `docker-compose up --build`.
- Truy cập thông qua: `localhost:3000`, `0.0.0.0:3000`.
- Dừng và xóa container: `docker-compose down`. 